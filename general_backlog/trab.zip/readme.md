A general backlog page with the use of some APIs
Giantbomb for games
TheMovieDataBase(TMDB) for movies
I still didn't add a books tab, but I guess I will use the Google books API
Each user can also create custom backlogs of anything they want(nothing criminal I hope)
Last thing I plan to add is a forum where users can talk between eachother about the items they add in the premade backlogs.


If for some crazy reason you are not me and found this repository, and for some even crazier reason want to run it in your machine, you will need to create a .env file with these variables: 

API_GAMES = [YOUR GIANT BOMB API KEY]
API_MOVIES = [YOUR TMDB API KEY]
MOVIES_BEARER = [YOUR TMBD API KEY BEARER]

(or simply replace them with the actual key in the app.js file)
